RECUPERADOR WHATSAPP - COMPILACIÓN EN LA NUBE

Este ZIP contiene un proyecto Android y un flujo de GitHub Actions para generar un APK de prueba en la nube.
No contiene todavía un APK compilado.

PASOS DESDE TU CELULAR
1. Descarga y extrae este ZIP.
2. En el navegador, inicia sesión o crea una cuenta en https://github.com/
3. Crea un repositorio nuevo llamado RecuperadorWhatsApp. Puedes dejarlo privado.
4. Sube el contenido de esta carpeta al repositorio, manteniendo las rutas y la carpeta oculta .github/workflows/build.yml.
   En GitHub, usa Add file > Upload files. Asegúrate de subir los archivos y carpetas que están dentro de la carpeta, no solo el ZIP.
5. En el repositorio, abre la pestaña Actions.
6. Selecciona "Compilar APK" y pulsa "Run workflow". Si no aparece, abre la pestaña Code y comprueba que el archivo .github/workflows/build.yml esté en la rama main.
7. Espera a que el trabajo termine con una marca verde.
8. Abre la ejecución terminada, baja hasta Artifacts y descarga "RecuperadorWhatsApp-debug".
9. Extrae el ZIP del artefacto descargado. Dentro estará app-debug.apk.
10. Toca el APK para instalarlo. Android puede pedir permiso para instalar aplicaciones desde el navegador o administrador de archivos.

NOTAS
- La primera compilación puede fallar por cambios o incompatibilidades en las herramientas; si ocurre, comparte el texto del error.
- Este proyecto inicial busca imágenes y videos existentes en una carpeta que el usuario autorice.
- No puede recuperar contenido "ver una sola vez" ya desaparecido, saltarse protecciones de WhatsApp ni restaurar archivos sobrescritos.
- El APK generado es una versión de prueba de depuración, no una versión firmada para publicar en Google Play.
