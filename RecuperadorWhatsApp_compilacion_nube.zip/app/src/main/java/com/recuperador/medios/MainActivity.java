package com.recuperador.medios;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.documentfile.provider.DocumentFile;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_FOLDER = 100;
    private static final int REQUEST_SAVE = 101;
    private static final int MAX_RESULTS = 500;

    private DocumentFile selectedFolder;
    private DocumentFile selectedFile;
    private final ArrayList<DocumentFile> results = new ArrayList<>();
    private LinearLayout listLayout;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("Recuperador WhatsApp");
        title.setTextSize(25);
        title.setPadding(0, 0, 0, 12);
        main.addView(title);

        TextView info = new TextView(this);
        info.setText("Busca fotos y videos que todavía existan en carpetas accesibles. No recupera contenido de ver una sola vez que ya desapareció.");
        info.setTextSize(15);
        main.addView(info);

        Button choose = new Button(this);
        choose.setText("1. Seleccionar carpeta");
        main.addView(choose);

        Button scan = new Button(this);
        scan.setText("2. Escanear imágenes y videos");
        main.addView(scan);

        status = new TextView(this);
        status.setText("Selecciona una carpeta para comenzar.");
        status.setTextSize(16);
        status.setPadding(0, 16, 0, 12);
        main.addView(status);

        ScrollView scroll = new ScrollView(this);
        listLayout = new LinearLayout(this);
        listLayout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listLayout);
        main.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(main);
        choose.setOnClickListener(v -> chooseFolder());
        scan.setOnClickListener(v -> scanFiles());
    }

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        startActivityForResult(intent, REQUEST_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        Uri uri = data.getData();
        if (uri == null) return;

        if (requestCode == REQUEST_FOLDER) {
            int flags = data.getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                     Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) { }

            selectedFolder = DocumentFile.fromTreeUri(this, uri);
            status.setText(selectedFolder != null
                    ? "Carpeta seleccionada. Pulsa escanear."
                    : "No se pudo abrir la carpeta.");
        } else if (requestCode == REQUEST_SAVE && selectedFile != null) {
            saveFile(uri);
        }
    }

    private void scanFiles() {
        if (selectedFolder == null || !selectedFolder.canRead()) {
            status.setText("Selecciona una carpeta accesible primero.");
            return;
        }

        results.clear();
        listLayout.removeAllViews();
        findMedia(selectedFolder);
        status.setText("Archivos encontrados: " + results.size());

        if (results.isEmpty()) {
            status.setText("No se encontraron fotos o videos accesibles. Prueba otra carpeta.");
            return;
        }

        for (DocumentFile file : results) {
            Button item = new Button(this);
            item.setText(file.getName() + "\n" + file.getType());
            item.setOnClickListener(v -> {
                selectedFile = file;
                String mime = file.getType();
                if (mime == null) mime = "*/*";

                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType(mime);
                save.putExtra(Intent.EXTRA_TITLE, file.getName());
                startActivityForResult(save, REQUEST_SAVE);
            });
            listLayout.addView(item);
        }
    }

    private void findMedia(DocumentFile folder) {
        if (results.size() >= MAX_RESULTS) return;
        DocumentFile[] files = folder.listFiles();

        for (DocumentFile file : files) {
            if (results.size() >= MAX_RESULTS) break;
            if (file.isDirectory()) {
                findMedia(file);
            } else if (file.isFile() && isMedia(file)) {
                results.add(file);
            }
        }
    }

    private boolean isMedia(DocumentFile file) {
        String mime = file.getType();
        if (mime == null) return false;
        mime = mime.toLowerCase(Locale.ROOT);
        return mime.startsWith("image/") || mime.startsWith("video/");
    }

    private void saveFile(Uri destination) {
        try (InputStream in = getContentResolver().openInputStream(selectedFile.getUri());
             OutputStream out = getContentResolver().openOutputStream(destination)) {
            if (in == null || out == null) {
                throw new Exception("No se pudo abrir el archivo.");
            }
            byte[] buffer = new byte[8192];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            out.flush();
            Toast.makeText(this, "Copia guardada correctamente", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "No se pudo guardar: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }
}
